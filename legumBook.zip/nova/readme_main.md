Install guide:
```
composer config repositories.laravel/nova git https://bitbucket.org/PatSpiegel/nova.git
composer require laravel/nova
```
