<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\JobController;
use App\Http\Controllers\NetworkController;
use App\Http\Controllers\MessagesController;
use App\Http\Controllers\GuestController;
use App\Http\Controllers\NotificationController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

//Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
  //  return $request->user();
//});
Route::prefix('auth')->group(function () {  
    Route::post('login', [UserController::class, 'login']);
    Route::post('register', [UserController::class, 'register']);
    Route::post('forget_password', [UserController::class, 'forgetPassword']);
    Route::post('verified_Otp', [UserController::class, 'verifiedOtp']);
    Route::post('change_Password', [UserController::class, 'changePassword']);

    Route::post('/google_login',[UserController::class, 'googleLogin']);




    Route::middleware('auth:sanctum')->group(function(){
        Route::post('logout',[UserController::class,'logout']);
        Route::get('/user', [UserController::class,'getUser']);
        Route::post('/update_profile_image',[UserController::class,'updateUserImage']);
        Route::post('/add_designation',[ProfileController::class,'addDesignation']);
        Route::post('/add_dob',[ProfileController::class,'addDob']);
        Route::post('/add_addres',[ProfileController::class,'addAddres']);
        Route::post('/add_education',[ProfileController::class,'addEducation']);
        Route::delete('/delete_education/{id}',[ProfileController::class,'deleteEducation']);
        Route::get('/view_education',[ProfileController::class,'viewEducation']);
        Route::put('/update_education',[ProfileController::class,'updateEducation']);
        Route::delete('/delete_/{id}',[ProfileController::class,'deleteEducation']);
        Route::post('/add_professional_details',[ProfileController::class,'addProfessionalDetails']);
        Route::put('/update_professional_details',[ProfileController::class,'updateProfessionalDetails']);
        Route::delete('/delete_professional_details/{id}',[ProfileController::class,'deleteProfessionalDetails']);
        Route::post('/add_bio',[ProfileController::class,'addBio']);
        Route::get('/profile',[ProfileController::class,'profile']);


        Route::post('/create_post',[PostController::class,'createPost']);
        Route::post('/like_post',[PostController::class,'likePost']);
        Route::get('/my_post',[PostController::class,'myPost']);
        Route::post('/post_comment',[PostController::class,'PostComment']);
        Route::get('/post',[PostController::class,'Post']);
        Route::post('/interested',[PostController::class,'interested']);
        Route::post('/edit_post',[PostController::class,'editPost']);
        Route::post('/delete_post_img',[PostController::class,'DeletePostimages']);
        Route::post('/add_post_img',[PostController::class,'AddPostImages']);



        Route::delete('/delete_post/{id}',[PostController::class,'DeletePost']);


        Route::post('/create_job',[JobController::class,'createJobs']);
        Route::get('/job',[JobController::class,'Jobs']);
        Route::get('/job/{id}',[JobController::class,'Job']);
        Route::get('/jobs_nears_you',[JobController::class,'JobsNearsYou']);
        Route::post('/apply_job',[JobController::class,'apply_job']);
        Route::get('/my_jobs',[JobController::class,'myJob']);
        Route::delete('/delete_job/{id}',[JobController::class,'DeleteJob']);
        Route::post('/updateJobs',[JobController::class,'updateJobs']);


        
        Route::post('/create_bookmark',[UserController::class,'createbookmark']);
        Route::get('/bookmark',[UserController::class,'bookmark']);
        Route::get('/search/{search}', [UserController::class, 'search']);

        Route::post('/request_to_network',[NetworkController::class,'requestToNetwork']);
        Route::get('/view_request',[NetworkController::class,'viewNetworkRequest']);
        Route::post('/accept_request',[NetworkController::class,'acceptRequest']);
        Route::post('/reject_request',[NetworkController::class,'rejectRequest']);
        Route::get('/my_network',[NetworkController::class,'viewMyNetwork']);


        Route::get('/messages/{sender_id}',[MessagesController::class,'index']);
        Route::post('/storeMessages',[MessagesController::class,'storeMessages']);
        Route::post('/readMessage',[MessagesController::class,'readMessage']);
        Route::get('/view_user/{userID}',[UserController::class,'viewUser']);
        Route::get('/user_message_list',[MessagesController::class,'messageList']);


        Route::get('/notification_list',[NotificationController::class,'notification']);
        Route::post('/read_notification',[NotificationController::class,'readNotification']);

       
    });
  
   Route::post('/question',[GuestController::class, 'Question']);
  
});