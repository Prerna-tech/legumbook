<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\GuestEmail;
use Illuminate\Support\Facades\Validator;
use App\Models\GuestQuestion;

class GuestController extends Controller
{
    public function Question(Request $request){
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email'=>'required',
            'question'=>'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
       $question= new GuestQuestion;
       $question->name=$request->name;
       $question->email=$request->email;
       $question->question=$request->question;
       $question->save();
        // Replace with the recipient's email address
      Mail::to('saxenarkmayank@gmail.com')->send(new GuestEmail($request));
    
    return response()->json(['message send Successfully'], 200);  }
}
