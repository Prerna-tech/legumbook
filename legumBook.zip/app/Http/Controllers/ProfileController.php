<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserProfile;
use App\Models\Education;
use App\Models\Work;
use App\Models\Users;
use Illuminate\Support\Facades\Validator;

class ProfileController extends Controller
{

    public function profile()
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $profile = Users::where('id', $user->id)->withCount('followerCount')->withCount('followingCount')->with('UserProfile')->with('education')->with('work')->get();
        if (!$profile) {
            return response()->json(['message' => 'Not Found'], 404);
        }
        return response()->json(['status' => 'success', 'data' =>  $profile], 200);
    }
    public function addDesignation(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'designation' => 'required',
            'purpose_to_use_app' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        if (UserProfile::where('user_id', $user->id)->exists()) {
            return response()->json([
                'message' => 'Designation Already Exists'
            ], 422);
        }
        $userProfile  = new UserProfile();
        $userProfile->user_id = $user->id;
        $userProfile->designation = $request->designation;
        $userProfile->purpose_to_use_app = $request->purpose_to_use_app;
        $userProfile->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Designation Add Successfully',
        ], 201);
    }

    public function addDob(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'dob' => 'required|date|date_format:Y-m-d|before:' . now()->subYears(10)->toDateString(),
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }

        UserProfile::where('user_id', $user->id)
            ->update([
                'dob' => $request->dob
            ]);
        return response()->json([
            'status' => 'success',
            'message' => 'DOB Add Successfully',
        ], 201);
    }

    public function addAddres(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'addres' => 'required',
            'city' => 'required',
            'state' => 'required',
            'zip' => 'required',
            'country' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }

        UserProfile::where('user_id', $user->id)
            ->update([
                'addres1' => $request->addres,
                'addres2' => $request->addres2,
                'city' => $request->city,
                'state' => $request->state,
                'zip' => $request->zip,
                'country' => $request->country
            ]);
        return response()->json([
            'status' => 'success',
            'message' => 'Address Add Successfully',
        ], 201);
    }

    public function addEducation(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'data' => 'required|array'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        $Edu = [];
        for ($i = 0; $i < count($request->data); $i++) {
            $Edu[] = [
                'user_id' => $user->id,
                'institution' => $request->data[$i]['institution'],
                'degree' => $request->data[$i]['degree'],
                'start_date' => $request->data[$i]['start_date'],
                'end_date' => $request->data[$i]['end_date'],
                'education_description' => $request->data[$i]['education_description']
            ];
        }
        Education::insert($Edu);
        return response()->json([
            'status' => 'success',
            'message' => 'Education Add Successfully',
        ], 201);
    }

    public function addProfessionalDetails(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'data' => 'required|array'
        ]);
        $validator = Validator::make($request->all(), [
            'data' => 'required|array'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        $work = [];
        for ($i = 0; $i < count($request->data); $i++) {
            $work[] = [
                'user_id' => $user->id,
                'title' => $request->data[$i]['title'],
                'type' => $request->data[$i]['type'],
                'company_name' => $request->data[$i]['company_name'],
                'location' => $request->data[$i]['location'],
                'employment_mode' => $request->data[$i]['employment_mode'],
                'start_date' => $request->data[$i]['start_date'],
                'current_working' => $request->data[$i]['current_working'],
                'end_date' => $request->data[$i]['end_date'],
                'work_description' => $request->data[$i]['work_description']
            ];
        }
        Work::insert($work);
        return response()->json([
            'status' => 'success',
            'message' => 'Education Add Successfully',
        ], 201);
    }
  
    
    public function updateProfessionalDetails(Request $request){
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'id' => 'required',
            'title' => 'required',
            'type' => 'required',
            'company_name' => 'required',
            'location' => 'required',
            'employment_mode' => 'required',
            'start_date' => 'required',
            'work_description' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        $work = Work::find($request->id);
        $work->user_id = $user->id;
        $work->title = $request->title;
        $work->type = $request->type;
        $work->company_name = $request->company_name;
        $work->location = $request->location;
        $work->employment_mode = $request->employment_mode;
        $work->start_date = $request->start_date;
        $work->current_working = $request->current_working;
        $work->end_date = $request->end_date;
        $work->work_description = $request->work_description;
        $work->save();
        return response()->json([
            'status' => 'success',
            'message' => 'Work Updated Successfully',
        ], 201);
    }



    public function addBio(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'bio' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }

        UserProfile::where('user_id', $user->id)
            ->update([
                'bio' => $request->bio
            ]);
        return response()->json([
            'status' => 'success',
            'message' => 'Bio Add Successfully',
        ], 201);
    }


    public function viewEducation()
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $edu = Education::where('user_id', $user->id)->get();
        if (!$edu) {
            return response()->json(['message' => 'No Network'], 204);
        }
        return response()->json(['data' =>  $edu], 200);
    }

    public function updateEducation(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'id' => 'required',
            'institution' => 'required',
            'degree' => 'required',
            'start_date' => 'required',
            'end_date' => 'required',
            'education_description' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        $eduction = Education::find($request->id);
        $eduction->user_id = $user->id;
        $eduction->institution = $request->institution;
        $eduction->degree = $request->degree;
        $eduction->start_date = $request->start_date;
        $eduction->end_date = $request->end_date;
        $eduction->education_description = $request->description;
        $eduction->save();
        return response()->json([
            'status' => 'success',
            'message' => 'Education Updated Successfully',
        ], 201);
    }


    public function deleteEducation($id){
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $eduction = Education::findOrFail($id);
        if($eduction->user_id!==$user->id ){
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $eduction->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'Education Deleted Successfully',
        ], 201);
    }



    public function deleteProfessionalDetails($id){
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $work = Work::findOrFail($id);
        if($work->user_id!==$user->id ){
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $work->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'Work Deleted Successfully',
        ], 201);
    }
}
