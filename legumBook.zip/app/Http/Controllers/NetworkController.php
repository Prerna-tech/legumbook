<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Network;
use App\Models\Users;
use App\Events\FriendRequestNotification;
use App\Models\Notification;

class NetworkController extends Controller
{
    public function requestToNetwork(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'receiver_id' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        if (!Users::where('id', $request->receiver_id)->exists()) {
            return response()->json([
                'message' => 'User Not Exists'
            ], 422);
        }
        $is_friend=Network::where('receiver_id',$request->receiver_id)
       ->where('sender_id', "=", $user->id)->first();
       if(isset($is_friend)){
         $friend =Network::find($is_friend->id);    
         $friend->delete();
         return response()->json([
            'status' => 'success',
            'message' => 'unfollow',
        ], 200);
       }
        $newRequest = new Network();
        $newRequest->sender_id = $user->id;
        $newRequest->receiver_id = $request->receiver_id;
        $newRequest->requested_at = today();
        $newRequest->save();

       
        $notification=new Notification();
        $notification->post_type='FOLLOW';
        $notification->content='Follow Request';
        $notification->owner_id=$request->receiver_id;
        $notification->user_id=$user->id;
        $notification->action_on=$newRequest->id;
        $notification->save();
        $data= Notification::with('user')->find($notification->id);
        broadcast(new FriendRequestNotification($data,$user->id,$request->receiver_id))->toOthers();
        return response()->json([
            'status' => 'success',
            'message' => 'Request Send Successfully',
        ], 201);
    }


    public function acceptRequest(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'sender_id' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
       $is_friend=Network::whereNotNull('accepted_at')->where('receiver_id', $user->id)
       ->where('sender_id', "=", $request->sender_id)->first();
       $is_frind2=Network::whereNotNull('accepted_at')->where('sender_id', $user->id)
       ->where('receiver_id', "=", $request->sender_id)->first();
       if(isset($is_friend)){
         $friend =Network::find($is_friend->id);    
         $friend->delete();
         return response()->json([
            'status' => 'success',
            'message' => 'unfollow',
        ], 200);
       }
       $is_frind2=Network::whereNotNull('accepted_at')->where('sender_id', $user->id)
       ->where('receiver_id', "=", $request->sender_id)->first();
       if(isset($is_frind2)){
         $friend =Network::find($is_frind2->id);    
         $friend->delete();
         return response()->json([
            'status' => 'success',
            'message' => 'unfollow',
        ], 200);
       }
        $accept = Network::where('receiver_id', $user->id)
            ->where('sender_id', "=", $request->sender_id)
            ->update([
                'accepted_at' => now()
            ]);
        if (!$accept) {
            return response()->json([
                'status' => 'error',
                'message' => 'something went wrong',
            ], 422);
        }
        return response()->json([
            'status' => 'success',
            'message' => 'Request Accepted Successfully',
        ], 201);
    }

     public function rejectRequest(Request $request){
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'sender_id' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
       $is_friend=Network::where('receiver_id', $user->id)
       ->where('sender_id', "=", $request->sender_id)->first();
       if(isset($is_friend)){
         $friend =Network::find($is_friend->id);    
         $friend->delete();
         return response()->json([
            'status' => 'success',
            'message' => 'unfollow',
        ], 200);
       }

     }


    public function viewNetworkRequest()
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $networkRequest = Network::where('receiver_id', $user->id)->where('accepted_at', null)->with('sender')->with('UserProfile')->get();
        if (!$networkRequest) {
            return response()->json([
                'status' => 'error',
                'message' => 'something went wrong',
            ], 204);
        }
        return response()->json([
            'status' => 'success',
            'data' => $networkRequest,
        ], 201);
    }


    public function viewMyNetwork()
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $myNetwork = Network::whereNotNull('accepted_at')->where('receiver_id','=',$user->id)->orWhere('sender_id','=',$user->id)->with('sender')->with('user')->with('UserProfile')->with('education')->get();
        if (!$myNetwork) {
            return response()->json([
                'status' => 'error',
                'message' => 'something went wrong',
            ], 204);
        }
        return response()->json([
            'status' => 'success',
            'data' => $myNetwork,
        ], 201);
    }
    
}
