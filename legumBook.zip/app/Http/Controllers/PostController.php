<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\LikePost;
use App\Models\PostComment;
use App\Models\HashTag;
use App\Models\Interested;
use App\Models\PostImage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\File;
use App\Events\FriendRequestNotification;
use App\Models\Notification;
use App\Nova\event;

class PostController extends Controller
{

    public function Post()
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $post = Post::with('user')->with('UserProfile')->with('hashtags')->with('PostImage')->withCount('like')->with('comment.user')->with('likedBy')->withCount('interested')->with('is_interested')->orderBy('id', 'DESC')->get();
        if (!$post) {
            return response()->json(['message' => 'Not Found'], 204);
        }
        return response()->json(['status' => 'success', 'data' =>  $post], 200);
    }

    public function myPost()
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $post = Post::where('user_id', $user->id)->with('user')->with('UserProfile')->with('hashtags')->withCount('like')->with('PostImage')->with('comment.user')->with('likedBy')->withCount('interested')->with('interested')->orderBy('id', 'DESC')->get();
        if (!$post) {
            return response()->json(['message' => 'Not Found'], 204);
        }
        return response()->json(['status' => 'success', 'data' =>  $post], 200);
    }



    public function createPost(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            // 'image' => 'required',
            'post_description' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        $storePath = storage_path('app/public/image/');
        if (!File::exists($storePath)) {
            File::makeDirectory($storePath);
        }
        $path = storage_path('app/public/image/' . $user->id . date('Y') . date('m'));
        if (!File::exists($path)) {
            File::makeDirectory($path);
        }
        // $request->description
        // return $request->data->getClientOriginalName();
        $newPost = new Post();
        $newPost->user_id = $user->id;
        $newPost->image = 'null';
        $newPost->event_title = $request->event_title;
        $newPost->post_description = $request->post_description;
        $newPost->event_start_at = $request->event_start_at;
        $newPost->event_end_at = $request->event_end_at;
        $newPost->library_title = $request->library_title;
        $newPost->library_link = $request->library_link;
        $newPost->save();
        $newPostID = $newPost->id;
        // return $request->post_description;


        //   $data = array(); 
        //return $request->data->getClientOriginalName();
        // $pk=[];
        // for($i=0; $i<3; $i++){
        //     $pk[]=$request->data[$i]->getClientOriginalName();
        // }
        // return  $pk;




        if (isset($request->data)) {
            $imageData = [];
            for ($i = 0; $i < count($request->data); $i++) {

                $imageName = $user->id . $i . time() . '.' . $request->data[$i]->extension();
                // return $imageName;
                $fullUrl = 'storage/image/' . $user->id . date('Y') . date('m') . '/' . $imageName;
                $request->data[$i]->move($path, $imageName);
                $imageData[] = [
                    'post_id' => $newPostID,
                    'image' => $fullUrl,
                ];
            }
            // return $imageData;
            PostImage::insert($imageData);
        }





        if (isset($request->tag)) {
            $hashTag = Post::find($newPostID);
            $hashTag->hashtag()->attach($request->tag);
            $hashTag->save();
        }
        return response()->json([
            'status' => 'success',
            'message' => 'Post Created Successfully',
        ], 201);
    }

    public function likePost(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'post_id' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        if (LikePost::where('user_id', $user->id)->where('post_id', $request->post_id)->exists()) {
            LikePost::where('user_id', $user->id)->where('post_id', $request->post_id)->delete();
            $postOwner=Post::find( $request->post_id);
           
            $notification=new Notification;
            $notification->post_type='POST';
            $notification->content='Remove Like Your Post';
            $notification->owner_id=$postOwner->user_id;
            $notification->user_id=$user->id;
            $notification->action_on=$postOwner->id;
            $notification->save();
            $data= Notification::with('user')->find($notification->id);
            event(new FriendRequestNotification($data,$user->id,$postOwner->user_id));
            return response()->json([
                'status' => 'success',
                'message' => 'Remove Like Successfully',
            ], 201);
        }
        $Like = new LikePost();
        $Like->user_id = $user->id;
        $Like->post_id = $request->post_id;
        $Like->save();
        $postOwner=Post::find( $request->post_id);
       
        $notification=new Notification;
        $notification->post_type='POST';
        $notification->content='Like Your Post';
        $notification->owner_id=$postOwner->user_id;
        $notification->user_id=$user->id;
        $notification->action_on=$postOwner->id;
        $notification->save();
        $data= Notification::with('user')->find($notification->id);
        broadcast(new FriendRequestNotification($data,$user->id,$postOwner->user_id))->toOthers();
        return response()->json([
            'status' => 'success',
            'message' => 'Like Successfully',
        ], 201);
    }

    public function PostComment(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'post_id' => 'required',
            'comment' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        if (!Post::where('id', $request->post_id)->exists()) {
            return response()->json([
                'message' => 'Post Does Not Exists'
            ], 422);
        }
        $Comment = new PostComment();
        $Comment->post_id = $request->post_id;
        $Comment->user_id = $user->id;
        $Comment->comment = $request->comment;
        $Comment->save();
        $postOwner=Post::find( $request->post_id);
       
        $notification=new Notification;
        $notification->post_type='POST';
        $notification->content='Comment On Your Post';
        $notification->owner_id=$postOwner->user_id;
        $notification->user_id=$user->id;
        $notification->action_on=$postOwner->id;
        $notification->save();
       
        $data= Notification::with('user')->find($notification->id);
        broadcast(new FriendRequestNotification($data,$user->id,$postOwner->user_id))->toOthers();
        return response()->json([
            'status' => 'success',
            'message' => 'Comment Successfully',
        ], 201);
    }



    public function editPost(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'id' => 'required',
            'post_description' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        $path = storage_path('app/public/image/' . $user->id . date('Y') . date('m'));
        if (!File::exists($path)) {
            File::makeDirectory($path);
        }
        

        //$post = Post::find($request->id);
       // return $post;
       $updateData = $request->only([
        'post_description',
        'event_title',
        'event_start_at',
        'event_end_at',
        'library_title',
        'library_link',
    ]);

      
    
    Post::where('id', $request->id)->update($updateData);
    // return $updateData;
    
        // $post->update($updateData);
        // $post->save();

        if (isset($request->old_image)) {
          
            for ($i = 0; $i < count($request->old_image); $i++) {

                $imageName =  $request->old_image[$i];
                //  return $imageName;
                if (file_exists($imageName)) {
                    File::delete($imageName);
                 
                 }
                PostImage::where('image', $imageName)->delete(); 
            }
            
        }
       

        if (isset($request->data)) {
            $imageData = [];
            for ($i = 0; $i < count($request->data); $i++) {

                $imageName = $user->id . $i . time() . '.' . $request->data[$i]->extension();
                // return $imageName;
                $fullUrl = 'storage/image/' . $user->id . date('Y') . date('m') . '/' . $imageName;
                $request->data[$i]->move($path, $imageName);
                $imageData[] = [
                    'post_id' => $request->id,
                    'image' => $fullUrl,
                ];
            }
            // return $imageData;
            PostImage::insert($imageData);
        }

        return response()->json([
            'status' => 'success',
            'message' => 'post updated successfully',
        ], 201);
    }

    // public function AddPostImages(Request $request)
    // {
    //     $user = auth()->user();
    //     if (!$user) {
    //         return response()->json(['message' => 'unauthorized'], 401);
    //     }
    //     $validator = Validator::make($request->all(), [

    //         // 'data' => 'required'
    //     ]);
    //     if ($validator->fails()) {
    //         return response()->json([
    //             'status' => 'error',
    //             'errors' => $validator->errors()
    //         ], 422);
    //     }

    //     $path = storage_path('app/public/image/' . $user->id . date('Y') . date('m'));
    //     if (!File::exists($path)) {
    //         File::makeDirectory($path);
    //     }
    //     // return  $request->data;
    //     if (isset($request->data)) {
    //         $imageData = [];
    //         for ($i = 0; $i < count($request->data); $i++) {

    //             $imageName = $user->id . $i . time() . '.' . $request->data[$i]->extension();
    //             // return $imageName;
    //             $fullUrl = 'storage/image/' . $user->id . date('Y') . date('m') . '/' . $imageName;
    //             $request->data[$i]->move($path, $imageName);
    //             $imageData[] = [
    //                 'post_id' => $request->id,
    //                 'image' => $fullUrl,
    //             ];
    //         }
    //         // return $imageData;
    //         PostImage::insert($imageData);
    //     }




    //     return response()->json([
    //         'status' => 'success',
    //         'message' => 'post images Add success',
    //     ], 201);
    // }
    public function DeletePostimages(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        //    return $request->old_image;
        if (isset($request->old_image)) {
            //$imageData = [];
            // return  $request->old_image;
            // return count($request->old_image);
            
            for ($i = 0; $i < count($request->old_image); $i++) {

                $imageName =  $request->old_image[$i];
                //  return $imageName;
                if (file_exists($imageName)) {
                    File::delete($imageName);
                    // delete from database too
                   
                 }
                PostImage::where('image', $imageName)->delete(); 
               
            }
            return response()->json([
                'status' => 'success',
                'message' => 'post image deleted',
            ], 201);
           
        }



        return response()->json([
            'status' => 'success',
            'message' => 'post image deleted',
        ], 201);
    }

    public function DeletePost($id)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $post = Post::findOrFail($id);
        if ($post->user_id !== $user->id) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $post->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'post deleted',
        ], 201);
    }



    public function interested(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'post_id' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        $is_added = Interested::where('user_id', '=', $user->id)->where('post_id', '=', $request->post_id)->exists();
        if ($is_added) {
            Interested::where('user_id', '=', $user->id)->where('post_id', '=', $request->post_id)->delete();
            return response()->json([
                'status' => 'success',
                'message' => 'Already Interested',
            ], 200);
        }

        $interested = new Interested();
        $interested->user_id = $user->id;
        $interested->post_id = $request->post_id;
        $interested->save();
        return response()->json([
            'status' => 'success',
            'message' => 'Add Interest Successfully',
        ], 201);
    }
}
