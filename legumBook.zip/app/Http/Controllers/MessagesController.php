<?php

namespace App\Http\Controllers;

use App\Events\SendMessage;
use App\Events\UnreadMessage;
use Illuminate\Http\Request;
use App\Models\Message;
use App\Models\Network;
use App\Models\Users;
use Illuminate\Support\Facades\Validator;
use BeyondCode\LaravelWebSockets\Facades\WebSocketsRouter;
use Illuminate\Support\Facades\DB;

class MessagesController extends Controller
{
    public function index($sender_id)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $message = Message::where([
            ['sender_id', '=', $sender_id],
            ['receiver_id', '=', $user->id]
        ])->orWhere([
            ['sender_id', '=', $user->id],
            ['receiver_id', '=', $sender_id]
        ])->orderBy('created_at', 'ASC')->get();
        if (!$message) {
            return response()->json(['message' => 'Not Found'], 404);
        }
        return response()->json(['status' => 'success', 'data' =>   $message], 200);
    }

    public function storeMessages(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'message' => 'required',
            'receiver_id' => 'required',
            'network_id'=>'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        $message = $request->message;
        $sender_id = $user->id;
        $receiver_id = $request->receiver_id;
        $newMessage = new Message;
        $newMessage->sender_id = $sender_id;
        $newMessage->receiver_id = $receiver_id;
        $newMessage->message = $message;
        $newMessage->network_id = $request->network_id;
        $newMessage->save();
     
        broadcast(new SendMessage($message,$sender_id,$request->receiver_id))->toOthers();
        $data=['sender_id'=>$sender_id,'message'=>$newMessage->message,'time'=>$newMessage->created_at];
        $unread=Message::whereNull('readed_on')->where('sender_id',$sender_id)->where('receiver_id',$receiver_id)->count();
        broadcast(new UnreadMessage($unread,$data,$sender_id,$request->receiver_id))->toOthers();
       return response()->json(['status' => 'Message sent']);
    }

    public function readMessage(Request $request)
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'sender_id' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        $lasmessage=Message::where([
            ['sender_id', '=', $request->sender_id],
            ['receiver_id', '=', $user->id]
        ])->orWhere([
            ['sender_id', '=', $user->id],
            ['receiver_id', '=', $request->sender_id]
        ])->orderBy('id','DESC')->first();
        
            Message::where('sender_id','=',$request->sender_id)->where('receiver_id','=',$user->id)->update(['readed_on'=>now()]);
        
        $data=['sender_id'=>$request->sender_id,'message'=>$lasmessage->message,'time'=>$lasmessage->created_at];
            $unread=Message::whereNull('readed_on')->where('receiver_id','=',$request->sender_id)->where('sender_id',$user->id)->count();
            broadcast(new UnreadMessage($unread,$data,$request->sender_id,$user->id))->toOthers();
       //return $unread;
    }


    public function messageList(){
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
    $myNetwork = Network::whereNotNull('accepted_at')->where('receiver_id','=',$user->id)->orWhere('sender_id','=',$user->id)->with('user') 
       ->with('sender')->with('lastMessage')->withCount('unreadMessage')->get();
        if (!$myNetwork) {
            return response()->json([
                'status' => 'error',
                'message' => 'something went wrong',
            ], 204);
        }
       
        return response()->json([
            'status' => 'success',
            'data' =>$myNetwork,
        ], 201);
    }
}
