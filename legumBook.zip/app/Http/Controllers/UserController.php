<?php

namespace App\Http\Controllers;

use App\Models\bookmark;
use Illuminate\Http\Request;
use App\Models\Users;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Models\Network;
use App\Models\ForgetPassword;
use App\Models\Jobs;
use Illuminate\Foundation\Auth\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail; 
use Carbon\Carbon;
use Carbon\CarbonInterval;

class UserController extends Controller
{
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|max:255',
            'email' => 'required|email|unique:users|max:255',
            'password'  => 'required|min:8',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => "email already exists"
            ], 422);
        }

        $user  = new Users();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = bcrypt($request->password);
        $user->save();

        
        Auth::attempt($user);
        $token = $user->createToken($user->name)->plainTextToken;

        return response()->json([
            'status' => 'success',
            'message' => 'Logged In Successfully',
            //'user' => $user,
            'token' => $token
        ], 201);
        // return response()->json(['status' => 'success', 'message' => 'Registered Successfully'], 201);
    }

    /**
     * login the user
     */
    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|exists:users',
            'password' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => "Invalid Credentials"
            ], 422);
        }
       
        $user = Users::where('email', $request->email)->first();
    
        if (!$user || !Hash::check($request->password, $user->password)) {
            return response()->json([
                'status' => 'error',
                'errors' => 'Invalid Credentials'
            ], 422);
        }
      
        $credentials = $request->only('email', 'password');
        Auth::attempt($credentials);
        $user->tokens()->delete();
        $token = $user->createToken($user->name)->plainTextToken;

        return response()->json([
            'status' => 'success',
            'message' => 'Logged In Successfully',
            'user' => $user,
            'token' => $token
        ], 201);
    }

    public function logout(Request $request)
    {
        $request->user()->tokens->each(function ($token, $key) {
            $token->delete();
        });
        //request()->user()->currentAccessToken()->delete();
        return response()->json([
            'status' => 'success',
            'msg' => 'Logged out Successfully.'
        ], 200);
    }

    public function getUser()
    {
        $user = request()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $query = "
            SELECT u.id, u.name, u.image,work.user_id,work.title,work.location,work.company_name,COUNT(f1.receiver_id) as mutual_friends
            FROM users AS u
            LEFT JOIN network AS f1 ON u.id = f1.sender_id
            LEFT JOIN network AS f2 ON u.id = f2.receiver_id
            LEFT JOIN  work  ON u.id=work.user_id
            WHERE u.id != $user->id
            GROUP BY u.id, u.name,u.image,work.user_id,work.title,work.location,work.company_name
        ";
       

        $result = DB::select($query);
        // Return the users with mutual friends counts
        if (!$result) {
            return response()->json(['message' => 'No Network'], 204);
        }
        return response()->json(['people_you_may_know' => $result]);
    }


    public function updateUserImage(Request $request)
    {

        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            'image' => 'required'
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        File::delete($user->image);
        $path1 = storage_path('app/public/image');
        if (!File::exists($path1)) {
            File::makeDirectory($path1);
        }
        $path2 = storage_path('app/public/image/profile');
        if (!File::exists($path2)) {
            File::makeDirectory($path2);
        }
        $path = storage_path('app/public/image/profile/' . $user->id);
        if (!File::exists($path)) {
            File::makeDirectory($path);
        }
        $imageName = $user->id . time() . '.' . $request->image->extension();
        $fullUrl = 'storage/image/profile/' . $user->id . '/' . $imageName;;
        $request->image->move($path, $imageName);
        Users::where('id', $user->id)
            ->update([
                'image' => $fullUrl
            ]);
        return response()->json([
            'status' => 'success',
            'image'=>$fullUrl,
            'message' =>'Image Update Successfully',
        ], 201);
    }

    public function viewUser($userID){
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        if(!isset($userID)){
            return response()->json(['message' => 'unauthorized'], 204);
        }
        $userWithDetail=Users::where('id',$userID)->withCount('postCount')->withCount('followerCount')->withCount('followingCount')->with('UserProfile')->with('education')->with('work')->first();
        $friend1=Network::where('sender_id','=',$userID)->where('receiver_id','=',$user->id)->first();
        $friend2=Network::where('receiver_id','=',$userID)->where('sender_id','=',$user->id)->first();
        if(isset($friend2)){
            $frinds=$friend2;
        }elseif(isset($friend1)){
            $frinds=$friend1;
        }else{
            $frinds=null;
        }

        return response()->json([
            'status' => 'success',
            'data' =>$userWithDetail,
            'is_friend'=> $frinds,
        ], 200);
    }
    public function createbookmark(Request $request )
    {
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $validator = Validator::make($request->all(), [
            
            'job_id' => 'required',
            
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        // return $request->job_features;
        $newbookmark=bookmark::where('user_id','=',$user->id)->where('job_id','=',$request->job_id)->exists();
        
        
        if($newbookmark)
        {
            bookmark::where('user_id','=',$user->id)->where('job_id','=',$request->job_id)->delete();
            
            return response()->json([
                'status' => 'success',
                'message' => 'bookmark delete  Successfully',
            ], 201);

        }
        $newJob = new bookmark();
        $newJob->user_id = $user->id;
        $newJob->job_id = $request->job_id;
        
        $newJob->save();
        
       


        return response()->json([
            'status' => 'success',
            'message' => 'bookmark Add Successfully',
        ], 201);
    }
    public function bookmark()
    {
        
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        
        $bookmark = bookmark::where('user_id','=',$user->id)->with('JobFeatures')->with('user')->with('job')->orderBy('id', 'DESC')->get();
        if ($bookmark->isEmpty()) {
            return response()->json(['message' => 'Not Found'], 204);
        }
        return response()->json(['status' => 'success', 'data' =>  $bookmark], 200);
    }
    // forgetPassword 
    public function forgetPassword(Request $request )
    {
        $validator = Validator::make($request->all(), [
            
            'email' => 'required|email|max:255',
            
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        try {
            $user = Users::where('email',$request->email)->get();
            if(count($user) > 0)
            {
                $otp = rand(100000,999999);
                $time = now();
                ForgetPassword::updateOrCreate(
                    ['email' => $request->email],
                    [
                    'email' => $request->email,
                    'token' => $otp,
                    'created_at' => $time
                    ]
                );
                $data['email'] = $request->email;
                $data['title'] = 'Mail Verification';
        
                $data['body'] = 'Your OTP is:- '.$otp;

                Mail::send([],['data'=>$data],function($message) use ($data){
                    $message->to($data['email'])->subject($data['title'])
                    ->html('<h4>'.$data['body'].'</h4>');
                });
                return response()->json(['status'=>'success','$msg'=>"plese check your mail"], 200);

            }else{
                return response()->json(['success'=>false,'msg'=>"email not found !"], 404);
            }
           
        } catch (\Exception $e) {
           return response()->json(['success'=>false,'$msg'=>$e->getMessage()], 500);
        }
    }
    public function verifiedOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            
            'email' => 'required|email|max:255',
            'otp'  => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        //$user = Users::where('email',$request->email)->where('token',)->first();
        $otpData = ForgetPassword::where('email',$request->email)->where('token',$request->otp)->first();
        if(!$otpData){

            return response()->json(['success' => false,'msg'=> 'You entered wrong OTP']);
        }
        else{

            $currentTime = now();
            $time = $otpData->created_at;
            $duration = $currentTime->diff($time)->format('%H:%I:%S');
            // $limit= "00:01:30";
           $convert = Carbon::createFromFormat('H:i:s',$duration)->diffInSeconds(Carbon::today());
           
            //   return $convert;
        //    $new= $limit->format('%H:%I:%S');

            if($convert <= '90'){//90 seconds

                ForgetPassword::where('email', $request->email)
                ->update([
                    'otp_varified' => "1"
                    
                ]);
                // ForgetPassword::where('email', $request->email)->delete();
                return response()->json(['success' => true,'msg'=> 'Mail has been verified'], 200);
            }
            else{
                return response()->json(['success' => false,'msg'=> 'Your OTP has been Expired'] ,410);
            }

        }
    }
    public function changePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            
           
            'email' => 'required',
            'password' => 'required|min:6|confirmed',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }
        $check=ForgetPassword::where('email', $request->email)->where('otp_varified',"1")->first();
        if(!$check){
            return response()->json([
                'status' => 'error',
                'errors' => 're-verify otp '
            ], 421);

        }

        Users::where('email', $request->email)
            ->update([
                'password' => bcrypt($request->password)
                
            ]);

       

        return response()->json([
            'status' => 'success',
            'message' => 'Password Change  Successfully',
           
        ], 200);
        
    }



    public function googleLogin(Request $request){
        $validator = Validator::make($request->all(), [
            'email' => 'required',
            'google_token' => 'required',
        ]);
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'errors' => $validator->errors()
            ], 422);
        }

        $user = Users::where('email',$request->email)->first();
        if(!$user){
            $user  = new Users();
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = bcrypt($request->google_token);
            $user->google_token=$request->google_token;
            $user->image= $request->image;
            $user->save();
        }
        Auth::login($user);
        $token = $user->createToken($user->name)->plainTextToken;
        return response()->json([
            'status' => 'success',
            'message' => 'Logged In Successfully',
            'user' => $user,
            'token' => $token
        ], 200);
    }


    public function search($search){
        $user = auth()->user();
        if (!$user) {
            return response()->json(['message' => 'unauthorized'], 401);
        }
        $users = Users::where('name', 'like', '%' . $search . '%')->get();
        $jobs=Jobs::where('role', 'like', '%' . $search . '%')->orWhere('titel', 'like', '%' . $search . '%')->
        orWhere('job_description', 'like', '%' . $search . '%')->orWhere('company_name', 'like', '%' . $search . '%')->get();
        $data=['user'=>$users,'job'=>$jobs];
         return response( $data );
    }
}
