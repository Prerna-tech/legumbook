<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HashTag extends Model
{
    use HasFactory;
    protected $table = "hashtag";
    protected $fillable = [
        'post_id', 'tag'
    ];
    public function post()
    {
        return $this->belongsToMany(Post::class, 'post_id', 'id');
    }
}
